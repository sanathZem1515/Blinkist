import React from 'react';
import Login from './Login';

export default {
    title: 'organisms/Login',
};

const Template = (args) => <Login {...args} />;

export const Default = Template.bind({});