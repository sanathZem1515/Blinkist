import React from 'react';
import Avatar from './Avatar'

export default {
    title: 'atoms/Avatar'
  }
  
  export const Default= () => <Avatar />