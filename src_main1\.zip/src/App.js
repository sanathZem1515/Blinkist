import { Container } from '@material-ui/core';
import React,{ useEffect, useState } from 'react';
import './App.css';
import Header from './Components/organisms/Header/Header';
import SearchBooks from './Components/organisms/SearchForm/SearchForm';
import { ThemeProvider } from '@material-ui/styles';
import theme from './theme';


function App() 
{
  const [searchVal,setSearchVal]=useState("");
  const [searchCat,setSearchCat]=useState("");
  const [view,setView]=useState("0");

  useEffect(()=>{
  },[searchVal,searchCat,view])

  const Printed = (search)=> {
    setSearchVal(search);
  }

  const handleCategory = (category) =>{
    setSearchCat(category);
  }
  
  const sendView = (view)=>{
      setView(view);
  }
  return (
    <ThemeProvider theme={theme}>
    <Container maxWidth="md">
    <Header click={Printed} handleCategory={handleCategory} sendView={sendView}/>
    <SearchBooks searchVal={searchVal} category={searchCat} view={view} />
    </Container>
    </ThemeProvider>
  );
}
export default App;
