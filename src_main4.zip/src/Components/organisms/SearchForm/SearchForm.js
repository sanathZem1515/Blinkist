import React, { useEffect, useState } from 'react';
import BookItem from '../Books/Books';
import CustomInput from '../../atoms/Input/Input';

const SearchBooks= (props) =>{
    console.log(props.category);
    const [searchValue,setSearchValue] = useState('');
    const updateHandler = (event)=>{
        setSearchValue(event.target.value);
    }

    useEffect(()=>{
    },[searchValue])

    return(
        <div style={{ paddingBottom: "30px"}}>
            { props.view === "1" && <CustomInput variant="standard" placeholder="Search by title or author" value={searchValue} onChange={updateHandler} />}
            <BookItem searchName={searchValue} searchVal={props.searchVal} category={props.category} view={props.view}/>
        </div>
    );
}
export default SearchBooks;