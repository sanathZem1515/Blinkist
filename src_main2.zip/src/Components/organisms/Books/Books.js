import React, { useState, useEffect } from 'react';
import CardItems from '../../molecules/Card/Card';
import { Grid } from '@material-ui/core';


const BookItem = (props) => {
  const [books, setBooks] = useState([]);
  const [currBooks,setCurrBooks] = useState([]);
  const [finBooks,setFinBooks] = useState([]);
  const [toggle,setToggle]=useState("0");

  // useEffect(()=>{
  // },[]);

  useEffect(() => {
    filterBooks();
    fetchAllBooks();

  }, [props.searchName,props.searchVal,props.category,props.view,toggle])
 
  const fetchAllBooks =async ()=>{
    await fetch('http://localhost:8086/books')
    .then(res => {
      return res.json();
    })
    .then(data => {
      setBooks(data);
    });
  }

  const forToggle = async () =>{  
    console.log("started toggling");
    setToggle(prevState => {
      if(prevState === "0")
        return "1";
      return "0";
  })
  console.log("completed toggling");
  } 

const filterBooks = () =>{
    setCurrBooks(books.filter((book)=>{
      return book.status === "current";
    }))

    setFinBooks(books.filter((book)=>{
      return book.status === "finished";
    }))
  }

var bookslist = books;
  if (props.searchName !== undefined && props.searchName!=="") {
    bookslist = books.filter(function (book) {
      return book.title.indexOf(props.searchName) > -1 || book.author.indexOf(props.searchName) > -1;
    })
  }
  if (props.searchVal !== undefined && props.searchVal!=="") {
    bookslist = books.filter(function (book) {
      return book.title.indexOf(props.searchVal) > -1 || book.author.indexOf(props.searchVal) > -1;
    })
  }
  if (props.category !== undefined && props.category!=="") {
    bookslist = books.filter(function (book) {
      return ((book.category.toLowerCase() === props.category.toLowerCase())&& book.status==="explore");
    })
  }

  const handleLibrary = async (library,id)=>{
    // var tempBook;
    console.log(library,id);
    if(library)
    {
      await fetch('http://localhost:8086/books/'+id)
        .then(res => {
          return res.json();
        })
        .then(data => {

        if(props.view==="0")
          data.status="finished";
        else if(props.view !=="0")
          data.status="current"
    // console.log(tempBook);

    fetch('http://localhost:8086/books/'+id, {
            method: 'PUT',
            body: JSON.stringify(data),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        });

        console.log("changed status to"+data.status);

        });

       await forToggle();
      }

   
    }
  
  
  const allbooks = bookslist.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} handleLibrary={handleLibrary} forToggle={forToggle}></CardItems>
      </Grid>
    );
  });

  console.log(currBooks);
  const currbooks = currBooks.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} name="Finish Reading" handleLibrary={handleLibrary} forToggle={forToggle}></CardItems>
      </Grid>
    );
  });
  const finbooks = finBooks.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} name="Read Again" handleLibrary={handleLibrary} forToggle={forToggle}></CardItems>
      </Grid>
    );
  });
  return (
    
    <Grid container spacing={2}>
      {props.view==="1" && allbooks}
      {props.view ==="0" && currbooks}
      {props.view==="2" && finbooks}
    </Grid>
  );
  }

export default BookItem;