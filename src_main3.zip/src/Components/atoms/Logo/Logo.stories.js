import React from 'react';
import Logo from './Logo';

export default {
    title: 'atoms/Logo'
  }
  
  export const Default= () => <Logo>Logo</Logo>