import React from 'react';
import CustomSearch from './Search';

export default {
    title: 'atoms/Search',
};

const Template = (args) => <CustomSearch {...args} />;

export const Default = Template.bind({});