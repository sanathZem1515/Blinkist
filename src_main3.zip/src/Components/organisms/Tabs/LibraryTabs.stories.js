import React from 'react';
import LibraryTabs from './LibraryTabs';
export default {
    title: 'organisms/LibraryTabs',
};

const Template = (args) => <LibraryTabs {...args} />;

export const Default = Template.bind({});