import React from 'react';
import Profile from './Profile';

export default {
    title: 'organisms/Profile',
};

const Template = (args) => <Profile {...args} />;

export const Default = Template.bind({});