import React, { useState, useEffect } from 'react';
import CardItems from '../BookCard/BookCard';
import { Grid } from '@material-ui/core';


const BookItem = (props) => {
  const [books, setBooks] = useState([]);
  const [currBooks, setCurrBooks] = useState([]);
  const [finBooks, setFinBooks] = useState([]);
 const  [toggle,setToggle]=useState(true);

  useEffect(() => {
    fetchAllBooks();
    filterBooks();
    //console.log("rendering....")
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.searchName, props.searchVal, props.category, props.view,toggle,books])

  const fetchAllBooks = async () => {
    await fetch('http://localhost:8086/books')
      .then(res => {
        return res.json();
      })
      .then(data => {
        setBooks(data);
      });
  }

  const filterBooks = () => {
    setCurrBooks(books.filter((book) => {
      return book.status === "current";
    }))

    setFinBooks(books.filter((book) => {
      return book.status === "finished";
    }))
  }

  // if(c)
  var bookslist = books;
  if (props.searchName !== undefined ) {
    bookslist = bookslist.filter(function (book) {
      return book.title.toLowerCase().indexOf(props.searchName.toLowerCase()) > -1 || book.author.toLowerCase().indexOf(props.searchName.toLowerCase()) > -1;
    })
  }
  if (props.searchVal !== undefined) {
    console.log(props.searchVal);
    bookslist = bookslist.filter(function (book) {
      return book.title.toLowerCase().indexOf(props.searchVal.toLowerCase()) > -1 || book.author.toLowerCase().indexOf(props.searchVal.toLowerCase()) > -1;
    }
    )
    console.log(bookslist)
  }
  
  if (props.category !== undefined && props.category !== "") {
    bookslist = bookslist.filter(function (book) {
      return ((book.category.toLowerCase() === props.category.toLowerCase()) && book.status === "explore");
    })
  }
  
  const handleLibrary = async (library, id) => {
    var tempBook;
    if (library) {
      await fetch('http://localhost:8086/books/' + id)
        .then(res => {
          return res.json();
        })
        .then(data => {
          tempBook = data;
        });
      const arr = ["explore", "current", "finished", "current"];
      let i = arr.indexOf(tempBook.status);
      tempBook.status = arr[i + 1];
      console.log(tempBook);
      await fetch('http://localhost:8086/books/' + id, {
        method: 'PUT',
        body: JSON.stringify(tempBook),
        headers: {
          "Content-type": "application/json; charset=UTF-8"
        }
      });
    }
    //filterBooks();
    //console.log("Before Toggle:" + toggle);
    setToggle(!toggle);
    //console.log("After Toggle:" + toggle);
  }

  console.log(bookslist);
  const allbooks = bookslist.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} handleLibrary={handleLibrary}></CardItems>
      </Grid>
    );
  });

  //console.log(currBooks);
  var currBooksList = currBooks;
  var finBooksList = finBooks;
  if(props.view==="0" && props.searchVal !== undefined && props.searchVal!=="") 
  {
    currBooksList=bookslist;
  }

  if(props.view==="2" && props.searchVal !== undefined && props.searchVal!=="")
  {
    finBooksList = bookslist;
  }
  const currbooks = currBooksList.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} name="Finish Reading" handleLibrary={handleLibrary}></CardItems>
      </Grid>
    );
  });
  const finbooks = finBooksList.map((item) => {
    return (
      <Grid item xs={4}>
        <CardItems key={item.id} {...item} name="Read Again" handleLibrary={handleLibrary}></CardItems>
      </Grid>
    );
  });
  return (

    <Grid container spacing={2}>
      {props.view === "1" && allbooks}
      {props.view === "0" && currbooks}
      {props.view === "2" && finbooks}
    </Grid>
  );
}

export default BookItem;